$( document ).ready(function() {

	   SalesPersonWiseContributionValue();
});

function SalesPersonWiseContributionValue( )
      {
      var margin = { top: 40, right: 10, bottom: 10, left: 10 },
          width = 400 - margin.left - margin.right,
          height = 180 - margin.top - margin.bottom;

      var percentage = function(d) { return d["percentage"]; };
       var PoSName = function(d) { return d["PoSName"]; };
       var SourceSite = function(d) { return d["SourceSite"]; };




      var colorScale = d3.scale.category20c();
      var color = function(d) { return d.children ? colorScale(d["Group"]) : null; }

      var treemap = d3.layout.treemap()
          .size([width, height])
          .sticky(true)
          .value(percentage,PoSName,SourceSite);
	

          d3.select("#SPWCV").html("");
      var div = d3.select("#SPWCV").append("div")
          .style("position", "relative")
          .style("width", (width + margin.left + margin.right) + "px")
          .style("height", (height + margin.top + margin.bottom) + "px")
          .style("left", margin.left + "px")
          .style("top", margin.top + "px");

          //console.log("Raju my freiends");

      var mousemove = function(d) {
        var xPosition = d3.event.pageX + 5;
        var yPosition = d3.event.pageY + 5;

        d3.select("#infotip")
          .style("left", xPosition + "px")
          .style("top", yPosition + "px");
        d3.select("#infotip #heading")
          .text("Salesperson:  "+d["demographics"]["Group"]);
        d3.select("#infotip #percentage")
          .text("Amount:  "+dollarFormatter(d["percentage"]));
         d3.select("#infotip #PoSName")
          .text("City: "+d["PoSName"]);
          d3.select("#infotip #SourceSite")
          .text("SourceSite: "+d["SourceSite"]);


        d3.select("#infotip").classed("hidden", false);
      };

      var mouseout = function() {
        d3.select("#infotip").classed("hidden", true);
      };
    var groupData = function(groupings, data, key){
        data.forEach(function(d){
          if(!groupings[d["Group"]]) {
            groupings[d["Group"]] = {};
          }
          if(!groupings[d["Group"]][d["Type"]]) {
         groupings[d["Group"]][d["Type"]] = {};
          }
          groupings[d["Group"]][d["Type"]][key] = d;
        });
      }

d3.json("http://localhost/MACV/SalesRepInsight/data/SalesPersonWiseContributionValue.php", function(error, data) {

var groupings = {}
  groupData(groupings, data, "demographics");
  var trees = [];
  for(group in groupings){
    var children = [];
    var children2 = [];
     var children3 = [];
    for(type in groupings[group]){
      var elm = groupings[group][type];
      var elm1 = groupings[group][type];
      var elm2 = groupings[group][type];

      
      elm["percentage"] = elm["demographics"]["percentage"];
      elm1["PoSName"] = elm1["demographics"]["PoSName"];
      elm2["SourceSite"] = elm2["demographics"]["SourceSite"];


      
      children3.push(elm2);
      children.push(elm);
      children2.push(elm1);
       
    }
    trees.push({"children": children,"children": children3,"children": children2,
                "Group": group});
  }

  //console.log("treeee",trees);

  var root = {"children": trees};
var node = div.datum(root).selectAll(".node")
      .data(treemap.nodes)
    .enter().append("div")
      .attr("class", "node")
      .call(position)
      .style("background", color)
      .on("mousemove", mousemove)
      .on("mouseout", mouseout);
  node.append("text")
      .classed("overlaidText",true)
      .text(function(d) {

//console.log("ddddddddddddddddddd",d);
       return d["Group"]})
      .call(middletext);
function middletext(text) {
  text.attr("x", function(d) { return x(d.x + d.dx / 2); })
      .attr("y", function(d) { return y(d.y + d.dy / 2); });
    }
    });


function position() {
  this.style("left", function(d) {return d.x + "px"; })
      .style("top", function(d) {return d.y + "px"; })
      .style("width", function(d) { return Math.max(0, d.dx) + "px";})
      .style("height", function(d) {
         return Math.max(0, d.dy) + "px"; 
      
 });
}

function dollarFormatter(n) {
      n = Math.round(n);
      var result = n;
      if (Math.abs(n) > 100000) {
        result = Math.round(n/100000) + 'L';
      }
      return  result;
    }

}
