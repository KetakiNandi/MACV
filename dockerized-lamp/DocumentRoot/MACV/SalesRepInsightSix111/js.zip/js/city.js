$( document ).ready(function() {

  	Macv_City();
  
  });


function Macv_City(spzone,Sstate,scity,Semp,SSite,Scate,prname){

  //console.log(spzone);

//d3.json("http://localhost/MACV/SalesRepInsight/data/city.php",function(data){

  var links;
  var Zone;
  var state;
  var EmpID;

var pCity=encodeURI("http://localhost/MACV/SalesRepInsight/data/city.php");


if (spzone === undefined && Sstate === undefined && scity === undefined && Semp === undefined && SSite === undefined && Scate === undefined && prname === undefined)
    {
        links=(pCity+"?param=");
    }
else if((spzone) && Sstate === undefined  && scity === undefined && Semp === undefined && SSite === undefined && Scate === undefined && prname === undefined)
    {
      links=(pCity+"?zoneparam="+spzone);
      //console.log(links);
    }

else if(spzone === undefined && Sstate && scity === undefined && Semp === undefined && SSite === undefined && Scate === undefined && prname === undefined )
    {
        links=(pCity+"?Stateparam="+Sstate);
    }

else if(spzone === undefined && Sstate === undefined && scity && Semp === undefined && SSite === undefined && Scate === undefined && prname === undefined)
    {
       links=(pCity+"?Cityparam="+scity);
    }
else if(spzone === undefined && Sstate === undefined && scity === undefined && Semp  && SSite === undefined && Scate === undefined  && prname === undefined)
    {
        links=(pCity+"?EmpIdparam="+Semp);
    }

else if (spzone === undefined && Sstate === undefined && scity === undefined && Semp === undefined && SSite && Scate === undefined  && prname === undefined)
    {
      links=(pCity+"?Siteparam="+SSite);
    }
else if(spzone === undefined && Sstate === undefined && scity === undefined && Semp === undefined && SSite === undefined && Scate === undefined && prname === undefined)
    {
      links=(pCity+"?categoryparam="+Scate);
    }

else
  {
    links=(pCity+"?ProNameparam="+prname)
  }


d3.json(links,function(error, data) {


      data.forEach(function(d) { 
    
            d.CIty = d.CIty;
      });



data.sort(function(a, c) { return c.count - a.count; });


d3.select("#MacDC").html("");

function wrap(text, width) {
        text.each(function() {
        var text = d3.select(this),
        words = text.text().split(/\s+/).reverse(),
        word,
        line = [],
        lineNumber = 0, //<-- 0!
        lineHeight = 1.2, // ems
        x = text.attr("x"), //<-- include the x!
        y = text.attr("y"),
        dy = text.attr("dy") ? text.attr("dy") : 0; //<-- null check
        tspan = text.text(null).append("tspan").attr("x", x).attr("y", y).attr("dy", dy + "em");
        while (word = words.pop()) {
            line.push(word);
            tspan.text(line.join(" "));
            /*if (tspan.node().getComputedTextLength() > width) {
                line.pop();
                tspan.text(line.join(" "));
                line = [word];
                tspan = text.append("tspan").attr("x", x).attr("y", y).attr("dy", ++lineNumber * lineHeight + dy + "em").text(word);
            }*/
        }
    });
}

var select = d3.select('#MacDC')
    .append('select')
    .attr('class','MacdivZ')
    .on("change", function(d){
       Macv_EmpId(Zone,state,this.options[this.selectedIndex].value,EmpID);
       Macv_State(Zone,state,this.options[this.selectedIndex].value,EmpID);
       Macv_Zone(Zone,state,this.options[this.selectedIndex].value,EmpID);
        Macv_SourceSite(Zone,state,this.options[this.selectedIndex].value,EmpID);
        Macv_Category(Zone,state,this.options[this.selectedIndex].value,EmpID);
        Macv_Promoname(Zone,state,this.options[this.selectedIndex].value,EmpID);

      });

 var selectUI = select
             .selectAll("option")
             .data(data)
             .enter()
             .append("option")
             //.attr("value", function(d){return d.CIty;})
             .text(function(d){return d.CIty;}).style("font-weight","bold").style("font-family",'Open Sans')
             .call(wrap, 50);
             
    });


}
