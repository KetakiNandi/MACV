$( document ).ready(function() {

  	Macv_State();
  
  });


function Macv_State(spzone,Sstate,scity,Semp,SSite,Scate,prname){

  //console.log(spzone,Sstate,scity,Semp ,Scate);

var links;
var Zone;
var city;
var EmpID;

var pState=encodeURI("http://localhost/MACV/SalesRepInsight/data/State.php");



if (spzone === undefined && Sstate === undefined && scity === undefined  && Semp === undefined && SSite === undefined  && Scate === undefined && prname === undefined)
   {
      links=(pState+"?param=");
   }

else if((spzone)&& Sstate === undefined && scity === undefined  && Semp === undefined && SSite === undefined  && Scate === undefined && prname === undefined)
    {
      links=(pState+"?zoneparam="+spzone);
    }

else if(spzone === undefined && Sstate && scity === undefined  && Semp === undefined && SSite === undefined  && Scate === undefined && prname === undefined)
    {
       links=(pState+"?Stateparam="+Sstate);
    }
else if(spzone === undefined && Sstate === undefined && scity  && Semp === undefined && SSite === undefined  && Scate === undefined && prname === undefined)
    {
        links=(pState+"?Cityparam="+scity);
    }
else if(spzone === undefined && Sstate === undefined && scity === undefined  && Semp && SSite === undefined  && Scate === undefined && prname === undefined)
    {
        links=(pState+"?EmpIdparam="+Semp);
    }

else if(spzone === undefined && Sstate === undefined && scity === undefined  && Semp === undefined && SSite  && Scate === undefined && prname === undefined)
   {
      links=(pState+"?Siteparam="+SSite);
   }

else if(spzone === undefined && Sstate === undefined && scity === undefined  && Semp === undefined && SSite === undefined  && Scate  && prname === undefined)
  {
  links=(pState+"?categoryparam="+Scate);
  }
else
{
   links=(pState+"?ProNameparam="+prname)
}


d3.json(links,function(error, data) {

 data.forEach(function(d) { 
    
    d.State = d.State;

});

     data.sort(function(a, c) { return c.count - a.count; });

      d3.select("#MacDS").html("");

      function wrap(text, width) {
        text.each(function() {
        var text = d3.select(this),
        words = text.text().split(/\s+/).reverse(),
        word,
        line = [],
        lineNumber = 0, //<-- 0!
        lineHeight = 1.2, // ems
        x = text.attr("x"), //<-- include the x!
        y = text.attr("y"),
        dy = text.attr("dy") ? text.attr("dy") : 0; //<-- null check
        tspan = text.text(null).append("tspan").attr("x", x).attr("y", y).attr("dy", dy + "em");
        while (word = words.pop()) {
            line.push(word);
            tspan.text(line.join(" "));
            /*if (tspan.node().getComputedTextLength() > width) {
                line.pop();
                tspan.text(line.join(" "));
                line = [word];
                tspan = text.append("tspan").attr("x", x).attr("y", y).attr("dy", ++lineNumber * lineHeight + dy + "em").text(word);
            }*/
        }
    });
}

var select = d3.select('#MacDS')
    .append('select')
    .attr('class','MacdivZ')
    .on("change", function(d){
       Macv_EmpId(Zone,this.options[this.selectedIndex].value,city,EmpID);
       Macv_City(Zone,this.options[this.selectedIndex].value,city,EmpID);
       Macv_Zone(Zone,this.options[this.selectedIndex].value,city,EmpID);
        Macv_SourceSite(Zone,this.options[this.selectedIndex].value,city,EmpID);
        Macv_Category(Zone,this.options[this.selectedIndex].value,city,EmpID);
        Macv_Promoname(Zone,this.options[this.selectedIndex].value,city,EmpID);

      });
    var selectUI = select
             .selectAll("option")
             .data(data)
             .enter()
             .append("option")
             //.attr("value", function(d){return d.State;})
             .text(function(d){return d.State;}).style("font-weight","bold").style("font-family",'Open Sans')
             .call(wrap, 50);
 
});

}
