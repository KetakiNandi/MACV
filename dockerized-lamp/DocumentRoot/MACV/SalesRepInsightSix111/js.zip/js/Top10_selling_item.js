$( document ).ready(function() {

	   PoSperformance();
});

function PoSperformance( )
      {
      var margin = { top: 40, right: 10, bottom: 10, left: 10 },
          width = 350 - margin.left - margin.right,
          height = 180 - margin.top - margin.bottom;

      var percentage = function(d) { return d["percentage"]; };
       var PoSName = function(d) { return d["PoSName"]; };

      var colorScale = d3.scale.category20c();
      var color = function(d) { return d.children ? colorScale(d["Group"]) : null; }

      var treemap = d3.layout.treemap()
          .size([width, height])
          .sticky(true)
          .value(percentage,PoSName);
	

          d3.select("#TopS").html("");
      var div = d3.select("#TopS").append("div")
          .style("position", "relative")
          .style("width", (width + margin.left + margin.right) + "px")
          .style("height", (height + margin.top + margin.bottom) + "px")
          .style("left", margin.left + "px")
          .style("top", margin.top + "px");

          //console.log("Raju my freiends");

      var mousemove = function(d) {
        var xPosition = d3.event.pageX + 5;
        var yPosition = d3.event.pageY + 5;

        d3.select("#infotip")
          .style("left", xPosition + "px")
          .style("top", yPosition + "px");
        d3.select("#infotip #heading")
          .text("Item Code:  "+d["demographics"]["Group"]);
        d3.select("#infotip #percentage")
          .text("QTY :  "+d["percentage"]);
         d3.select("#infotip #PoSName")
          .text("First SubCategory: "+d["PoSName"]);

        d3.select("#infotip").classed("hidden", false);
      };

      var mouseout = function() {
        d3.select("#infotip").classed("hidden", true);
      };
    var groupData = function(groupings, data, key){
        data.forEach(function(d){
          if(!groupings[d["Group"]]) {
            groupings[d["Group"]] = {};
          }
          if(!groupings[d["Group"]][d["Type"]]) {
         groupings[d["Group"]][d["Type"]] = {};
          }
          groupings[d["Group"]][d["Type"]][key] = d;
        });
      }

d3.json("http://localhost/MACV/SalesRepInsight/data/Top10SellingItem.php", function(error, data1) {

var data=[];
  var counter=1;
    for(var i=0;i<data1.length;i++){
       var fdata = (data1[i].Group);
        var fdata2 = (data1[i].percentage);
        var fdata3 = (data1[i].PoSName);

         data.push({Group:fdata,percentage:fdata2,PoSName:fdata3});


      if(counter==10)
      {
        counter=0
          break;
      }

        counter++;
    }


 //console.log("ggggggggg",JSON.stringify(Arrray));

var groupings = {}
  groupData(groupings, data, "demographics");
  var trees = [];
  for(group in groupings){
    var children = [];
    var children2 = [];
    for(type in groupings[group]){
      var elm = groupings[group][type];
      var elm1 = groupings[group][type];

      
      elm["percentage"] = elm["demographics"]["percentage"];
      elm1["PoSName"] = elm1["demographics"]["PoSName"];

      

      children.push(elm);
      children2.push(elm1);
    }
    trees.push({"children": children,"children": children2,
                "Group": group});
  }

  //console.log("treeee",trees);

  var root = {"children": trees};
var node = div.datum(root).selectAll(".node")
      .data(treemap.nodes)
    .enter().append("div")
      .attr("class", "node")
      .call(position)
      .style("background", color)
      .on("mousemove", mousemove)
      .on("mouseout", mouseout);
  node.append("text")
      .classed("overlaidText",true)
      .text(function(d) {

        //console.log("ssssssssssss",d["Group"]);


        return d["Group"]})

.call(middletext);
function middletext(text) {
  text.attr("x", function(d) { return x(d.x + d.dx / 2); })
      .attr("y", function(d) { return y(d.y + d.dy / 2); });
    }
    });


function position() {
  this.style("left", function(d) {return d.x + "px"; })
      .style("top", function(d) {return d.y + "px"; })
      .style("width", function(d) { return Math.max(0, d.dx) + "px";})
      .style("height", function(d) {
         return Math.max(0, d.dy) + "px"; 
      
 });
}


}
