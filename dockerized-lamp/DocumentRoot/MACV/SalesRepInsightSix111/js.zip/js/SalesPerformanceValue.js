$( document ).ready(function() {	

    SalesPerformanceValue();
});

function SalesPerformanceValue(){

	//console.log("ssssssssssssssss",startDate,endDate)

    var margin = {top: 20, right: 20, bottom: 30, left: 40},
      width = 500 - margin.left - margin.right,
      height = 150 - margin.top - margin.bottom

    var x = d3.scale.ordinal()
        .rangeRoundBands([0, width/2], .1);

    var y = d3.scale.linear()
        .range([height/2, 0]);

    var xAxis = d3.svg.axis()
        .scale(x)
       .orient("bottom")
       .tickFormat(d3.time.format("%b-%Y"));

    var yAxis = d3.svg.axis();

  
   
  var div = d3.select("body").append("div").attr("class", "toolTip");

  var commaFormat = d3.format(',');

  
  var svg = d3.select("#SPV").append("svg")
        .attr("id","SPVR")
        .attr("width", 280)
        .attr("height", 200)
        .append("g")
        .attr("transform", "translate(" + 30 + "," + 50 + ")");
    

 d3.json("http://localhost/MACV/SalesRepInsight/data/SalesPerformanceValue.php", function(data) {

  var fmt = d3.time.format.utc("%b-%Y").parse;

  var fmt1 = d3.time.format.utc("%b-%Y");

     data.forEach(function(d) {
        d.Month = fmt(d.Month);
        d.Count = +d.Amount;

       });

     

data.sort(sortByDateAscending);

  function sortByDateAscending(a,b){
  return new Date(a.Month)-new Date(b.Month);
  }

data.forEach(function(d) {
        d.Month = fmt1(d.Month);
        d.Count = +d.Count;

       });

var currentMonth = (new Date).getMonth();
 var currentQuarter = Math.floor(((currentMonth + 11) / 3) % 4) + 1;




     x.domain(data.map(function(d) { return d.Month;}));
     y.domain([0, d3.max(data, function(d) {return d.Count; })]);

    var yaxis = svg.append("g")
        .attr("class", "y axis")
        //.call(d3.svg.axis().scale(y).orient("left"))
        .selectAll("text")
        .style("text-anchor", "end")
        .attr("dx", "-.1em")
        .attr("dy", "-.1em")
        .attr("fill",'#ffff');
        

    var xaxis = svg.append("g")
        .attr("class", "x axis")
        .attr("transform", "translate(0," + 100 + ")")
        .call(d3.svg.axis().scale(x).orient("bottom"))
        .selectAll("text")
        .style("text-anchor", "end")
        .style("font-size", "8px")
        .attr("dx", "-.1em")
        .attr("dy", "-.1em")
        .attr("transform", function(d) { return "rotate(-35)" });

     svg.selectAll(".bar")
        .data(data)
        .enter().append("rect")
        .attr("class", "bar")
        .attr("x", function(d) { return x(d.Month); })
        .attr("width", x.rangeBand())
        .attr("y", function(d) { return y(d.Count); })
        .attr("height", function(d) { return height - y(d.Count); })
         .on("mousemove", function(d){
              div.style("left", d3.event.pageX+10+"px");
              div.style("top", d3.event.pageY-25+"px");
              div.style("display", "inline-block");
              div.html("<span style='color:#ffffff'>" +"Bill Date Month: " +d.Month +"<br/>"+"Amounts: " +commaFormat(d.Count)+"</span>");           
          })
      .on("mouseout", function(d){
              div.style("display", "none");
          });


/*
svg.selectAll("text.bar")
  .data(data)
  .enter().append("text")
  .attr("text-anchor", "middle")
  .attr("x", function(d) { return x(d.Month)+20; })
  .attr("y", function(d) { return y(d.Count)-10; })
  .style("fill","white")
  .text(function(d) { return (dollarFormatterK(d.Count)); });*/





  });

 function dollarFormatterK(n) {
  n = Math.round(n);
  var result = n;
  if (Math.abs(n) > 1000) {
    result = Math.round(n/1000)+'K';
  }
  return result;
}
  

}
