$( document ).ready(function() {

  	Macv_Promoname();
  
  });


function Macv_Promoname(spzone,Sstate,scity,Semp,SSite,Scate){

      //d3.json("http://localhost/MACV/SalesRepInsight/data/promoName.php",function(data){

      var links;
      var Zone;
      var city;
      var EmpID;
      var Division;
      var state;
      var SourceSite;


      var pName=encodeURI("http://localhost/MACV/SalesRepInsight/data/promoName.php");



      if (spzone === undefined && Sstate === undefined && scity === undefined  && Semp === undefined  && SSite === undefined  && Scate === undefined) {

          links=(pName+"?param=");

         }

       else if((spzone)&& Sstate === undefined && scity === undefined  && Semp === undefined && SSite === undefined  && Scate === undefined)
          {

             links=(pName+"?zoneparam="+spzone);



            }

      else if(spzone === undefined && Sstate && scity === undefined  && Semp === undefined && SSite === undefined  && Scate === undefined)
          {
             links=(pName+"?Stateparam="+Sstate);

               console.log(links);

           
          }
      else if(spzone === undefined && Sstate === undefined && scity  && Semp === undefined && SSite === undefined  && Scate === undefined)
        {

        links=(pName+"?Cityparam="+scity);

        }

      else if(spzone === undefined && Sstate === undefined && scity === undefined  && Semp  && SSite === undefined  && Scate === undefined)
      {
        links=(pName+"?EmpIdparam="+Semp);

      }

      else if (spzone === undefined && Sstate === undefined && scity === undefined  && Semp === undefined  && SSite  && Scate === undefined)
      {
        links=(pName+"?Siteparam="+SSite);

      }

      else
      {

      links=(pName+"?categoryparam="+Scate);

      }

      d3.json(links,function(error, data) {

          data.forEach(function(d) { 
          
          d.PromoName = d.PromoName;

      });

      data.sort(function(a, c) { return c.count - a.count; });


      d3.select("#MacDPRN").html("");

      function wrap(text, width) {
        text.each(function() {
        var text = d3.select(this),
        words = text.text().split(/\s+/).reverse(),
        word,
        line = [],
        lineNumber = 0, //<-- 0!
        lineHeight = 1.2, // ems
        x = text.attr("x"), //<-- include the x!
        y = text.attr("y"),
        dy = text.attr("dy") ? text.attr("dy") : 0; //<-- null check
        tspan = text.text(null).append("tspan").attr("x", x).attr("y", y).attr("dy", dy + "em");
        while (word = words.pop()) {
            line.push(word);
            tspan.text(line.join(" "));
            /*if (tspan.node().getComputedTextLength() > width) {
                line.pop();
                tspan.text(line.join(" "));
                line = [word];
                tspan = text.append("tspan").attr("x", x).attr("y", y).attr("dy", ++lineNumber * lineHeight + dy + "em").text(word);
            }*/
        }
    });
}

var select = d3.select('#MacDPRN')
    .append('select')
    .attr('class','MacdivZ')
    .on("change", function(d){
       Macv_Zone(Zone,state,city,EmpID,SourceSite,Division,this.options[this.selectedIndex].value);
      Macv_Category(Zone,state,city,EmpID,SourceSite,Division,this.options[this.selectedIndex].value);
      Macv_EmpId(Zone,state,city,EmpID,SourceSite,Division,this.options[this.selectedIndex].value);
      Macv_SourceSite(Zone,state,city,EmpID,SourceSite,Division,this.options[this.selectedIndex].value);
      Macv_City(Zone,state,city,EmpID,SourceSite,Division,this.options[this.selectedIndex].value);
      Macv_State(Zone,state,city,EmpID,SourceSite,Division,this.options[this.selectedIndex].value);


      });
    var selectUI = select
             .selectAll("option")
             .data(data)
             .enter()
             .append("option")
                   .text(function(d){return d.PromoName;}).style("font-weight","bold").style("font-family",'Open Sans')
                   .call(wrap, 50);
          });

}
