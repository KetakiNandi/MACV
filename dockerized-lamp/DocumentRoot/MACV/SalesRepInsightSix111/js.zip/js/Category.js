$( document ).ready(function() {

  	Macv_Category();
  
  });


function Macv_Category(spzone,Sstate,scity,Semp,SSite,Scate,prname){

//d3.json("http://localhost/MACV/SalesRepInsight/data/Category.php",function(data){


var links;
var Zone;
var city;
var EmpID;
var SourceSite;
var state;


  var pCategory=encodeURI("http://localhost/MACV/SalesRepInsight/data/Category.php");



if (spzone === undefined && Sstate === undefined && scity === undefined  && Semp === undefined && SSite === undefined && Scate === undefined && prname === undefined)

    {
      links=(pCategory+"?param=");
    }

else if((spzone)&& Sstate === undefined && scity === undefined  && Semp === undefined && SSite === undefined && Scate === undefined && prname === undefined)
    {

    links=(pCategory+"?zoneparam="+spzone);
    }

else if(spzone === undefined && Sstate && scity === undefined  && Semp === undefined && SSite === undefined && Scate === undefined && prname === undefined)
    {
       links=(pCategory+"?Stateparam="+Sstate);
    }
else if(spzone === undefined && Sstate === undefined && scity  && Semp === undefined && SSite === undefined && Scate === undefined && prname === undefined)
   {

   links=(pCategory+"?Cityparam="+scity);
    
   }

else if (spzone === undefined && Sstate === undefined && scity === undefined  && Semp && SSite === undefined && Scate === undefined && prname === undefined)
   {

   links=(pCategory+"?EmpIdparam="+Semp);
    
  }

else if(spzone === undefined && Sstate === undefined && scity === undefined  && Semp === undefined && SSite  && Scate === undefined && prname === undefined)
  
  {
    links=(pCategory+"?Siteparam="+SSite);
  }

else if (spzone === undefined && Sstate === undefined && scity === undefined  && Semp === undefined && SSite === undefined && Scate && prname === undefined)
{
  links=(pCategory+"?categoryparam="+Scate);
}

else 
{

links=(pCategory+"?ProNameparam="+prname);

}

function wrap(text, width) {
        text.each(function() {
        var text = d3.select(this),
        words = text.text().split(/\s+/).reverse(),
        word,
        line = [],
        lineNumber = 0, //<-- 0!
        lineHeight = 1.2, // ems
        x = text.attr("x"), //<-- include the x!
        y = text.attr("y"),
        dy = text.attr("dy") ? text.attr("dy") : 0; //<-- null check
        tspan = text.text(null).append("tspan").attr("x", x).attr("y", y).attr("dy", dy + "em");
        while (word = words.pop()) {
            line.push(word);
            tspan.text(line.join(" "));
            /*if (tspan.node().getComputedTextLength() > width) {
                line.pop();
                tspan.text(line.join(" "));
                line = [word];
                tspan = text.append("tspan").attr("x", x).attr("y", y).attr("dy", ++lineNumber * lineHeight + dy + "em").text(word);
            }*/
        }
    });
}


d3.json(links,function(error, data) {

    data.forEach(function(d) { 
    
             d.Division = d.Division;
          });

        d3.select("#MacDPG").html("");
var select = d3.select('#MacDPG')
    .append('select')
    .attr('class','MacdivZ')
    .on("change", function(d){
       Macv_Zone(Zone,state,city,EmpID,SourceSite,this.options[this.selectedIndex].value);
       Macv_State(Zone,state,city,EmpID,SourceSite,this.options[this.selectedIndex].value);
       Macv_City(Zone,state,city,EmpID,SourceSite ,this.options[this.selectedIndex].value);
       Macv_SourceSite(Zone,state,city,EmpID,SourceSite,this.options[this.selectedIndex].value);
       Macv_Promoname(Zone,state,city,EmpID,SourceSite,this.options[this.selectedIndex].value);
       Macv_EmpId(Zone,state,city,EmpID,SourceSite,this.options[this.selectedIndex].value);

       SalesPerformanceValue(Zone,state,city,EmpID,SourceSite,this.options[this.selectedIndex].value);
       SalesPersonWiseContributionQuantity(Zone,state,city,EmpID,SourceSite,this.options[this.selectedIndex].value);
       SalesPerformanceQtns(Zone,state,city,EmpID,SourceSite,this.options[this.selectedIndex].value);
       render_avgSoldPerDay(Zone,state,city,EmpID,SourceSite,this.options[this.selectedIndex].value);
       CategorywisePerformanceQuantity(Zone,state,city,EmpID,SourceSite,this.options[this.selectedIndex].value);
       SubCategorywisePerformanceQuantity(Zone,state,city,EmpID,SourceSite,this.options[this.selectedIndex].value);
       CustomerDetailsFilled(Zone,state,city,EmpID,SourceSite,this.options[this.selectedIndex].value);
       SalesPersonWiseContributionValue(Zone,state,city,EmpID,SourceSite,this.options[this.selectedIndex].value);
      });
    var selectUI = select
             .selectAll("option")
             .data(data)
             .enter()
             .append("option")
                    // .attr("value", function(d){return d.Division;})
                     .text(function(d){return d.Division;}).style("font-weight","bold").style("font-family",'Open Sans')
                     .call(wrap, 50);
        });


}
