$( document ).ready(function() {	

    render_avgSoldPerDay();

});

function render_avgSoldPerDay(){

   var margin = {top: 40, right: 20, bottom: 30, left: 20},
      width = 800 - margin.left - margin.right,
      height = 100 - margin.top - margin.bottom

    var x = d3.scale.ordinal()
        .rangeRoundBands([0, width/2],.2);

    var y = d3.scale.linear()
        .range([height/2, 0]);

    var xAxis = d3.svg.axis()
        .scale(x)
        .orient("bottom");

    var yAxis = d3.svg.axis();

   

var div = d3.select("body").append("div").attr("class", "toolTip");


    var svg = d3.select("#SAQP").append("svg")
        .attr("id","SUPC")
        .attr("width", 400)
        .attr("height", 200)
        .append("g")
        .attr("transform", "translate(" + 10 + "," + 130 + ")");
    
    //svg.call(tip);

     var links;

  d3.json("http://localhost/MACV/SalesRepInsight/data/saleAvgQtnPerDay.php", function(json) {

    var data=json;

    data.forEach(function(d){
            if(d.PosCode=='QRILQRIL029')
                {
                    d.PosCode = "QRIL029";
                }
                });
    data.sort(function(a, c) { return c.QtnPerDay - a.QtnPerDay; });

    //console.log("ffffff",JSON.stringify(data));

    x.domain(data.map(function(d) { 
        return d.PosCode;}));
    y.domain([0, d3.max(data, function(d) { 
      return (d.QtnPerDay); })]);

 var xaxis = svg.append("g")
        .attr("class", "x axis")
        .attr("transform", "translate(0," + 30+ ")")
        .call(d3.svg.axis().scale(x).orient("bottom"))
        .selectAll("text")
        .style("text-anchor", "end")
        .style("font-size", "8px")
        .attr("dx", "-.1em")
        .attr("dy", ".35em")
        .attr("transform", function(d) { return "rotate(-45)" });

     svg.selectAll(".bar")
        .data(data)
        .enter().append("rect")
        .attr("class", "bar")
        .attr("x", function(d) { return x(d.PosCode); })
        .attr("width", x.rangeBand())
        .attr("y", function(d) {return y(d.QtnPerDay); })
        .attr("height", function(d) { return height - y(d.QtnPerDay); })
        .on("mousemove", function(d){
              div.style("left", d3.event.pageX+10+"px");
              div.style("top", d3.event.pageY-25+"px");
              div.style("display", "inline-block");
              div.html("<span style='color:#ffffff'>" +"Pos Code: " +d.PosCode +"<br/>"+"Qtn Per Day: " +d.QtnPerDay+"<br/>"+"Pos Name: "+d.PosName+ "</span>");           
          })
      .on("mouseout", function(d){
              div.style("display", "none");
          });

  });
}
