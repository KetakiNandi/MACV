$( document ).ready(function() {

  	Macv_EmpId();
  
  });


function Macv_EmpId(spzone,Sstate,scity,Semp,SSite,Scate,prname){

// d3.json("http://localhost/MACV/SalesRepInsight/data/empID.php", function(data) {

var links;

var Zone;
var city;
var EmpID;
var Division;
var state;
var SourceSite;


 var pEmpId=encodeURI("http://localhost/MACV/SalesRepInsight/data/empID.php");




if (spzone === undefined && Sstate === undefined && scity === undefined  && Semp === undefined && SSite === undefined && Scate === undefined && prname === undefined)
  
  {

    links=(pEmpId+"?param=");


    }

 else if((spzone)&& Sstate === undefined && scity === undefined && Semp === undefined && SSite === undefined && Scate === undefined && prname === undefined)
    {

       links=(pEmpId+"?zoneparam="+spzone);

    }

else if(spzone === undefined && Sstate  && scity === undefined && Semp === undefined && SSite === undefined && Scate === undefined && prname === undefined)
    {
       links=(pEmpId+"?Stateparam="+Sstate);
    }
else if(spzone === undefined && Sstate === undefined && scity   && Semp === undefined && SSite === undefined && Scate === undefined && prname === undefined)
  {
  links=(pEmpId+"?Cityparam="+scity);

  }

  else if(spzone === undefined && Sstate === undefined && scity === undefined  && Semp && SSite === undefined && Scate === undefined && prname === undefined)

  {

    links=(pEmpId+"?EmpIdparam="+Semp);
  }

else if(spzone === undefined && Sstate === undefined && scity === undefined  && Semp === undefined && SSite  && Scate === undefined && prname === undefined)

{

  links=(pEmpId+"?Siteparam="+SSite);

  console.log(links)

}

else if(spzone === undefined && Sstate === undefined && scity === undefined  && Semp === undefined && SSite === undefined && Scate &&prname === undefined)
{

  links=(pEmpId+"?categoryparam="+Scate);


}

else
{

links=(pEmpId+"?ProNameparam="+prname);

}


d3.json(links,function(error, data) {

        data.forEach(function(d) { 

                d.EmpID = d.EmpID;
                d.EmpName =d.EmpName;

              });


data.sort(function(a, b){
    if(a.EmpName < b.EmpName) return -1;
    if(a.EmpName > b.EmpName) return 1;
    return 0;
});

d3.select("#MacDEid").html("");
var svg = d3.select("#MacDEid")
   .selectAll("foreignObject")
   .data(data).enter()
   .append("foreignObject")
   .append("xhtml:body")
   .attr("class", "bforeign")
   //.attr("fill", "green")
   .html(function(d) {
    if(d.EmpName != "#N/A")
   { //console.log(d.EmpName);
return "<form><input type=checkbox class=che  id=check ><span><button class=Macd >" + d.EmpName + "</button></span> </form>";
}
})
 
 .on("click", function(d){

  Macv_Zone(Zone,state,city,d.EmpID);
  Macv_State(Zone,state,city,d.EmpID);
  Macv_City(Zone,state,city,d.EmpID);
  Macv_SourceSite(Zone,state,city,d.EmpID);
  Macv_Category(Zone,state,city,d.EmpID);
  Macv_Promoname(Zone,state,city,d.EmpID);
  
  
	$('input.che').on('change', function() {
    $('input.che').not(this).prop('checked', false);  
    });


   });
    
 });

}
