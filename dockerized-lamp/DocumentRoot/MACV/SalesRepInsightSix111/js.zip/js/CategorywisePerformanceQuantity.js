$( document ).ready(function() {
  CategorywisePerformanceQuantity();
});

function remove(property, num, arr) {
    for (var i in arr) {
        if (arr[i][property] == num)
            arr.splice(i, 1);
    }
}

function CategorywisePerformanceQuantity(spzone,Sstate,scity,Semp,SSite,Scate,prname,CatQtn){
        //console.log("EEEEEEEEEEEEEEEE",pros,prosEmpId );

        var colorRange = d3.scale.category20();
        var color = d3.scale.ordinal().range(colorRange.range());
        var width = 230,
             height =220,
             radius=100;

        var arc = d3.svg.arc().outerRadius(radius - 100).innerRadius(radius - 50);
        var outerArc = d3.svg.arc().innerRadius(radius - 60).outerRadius(radius - 60);

        var svg = d3.select("#NZEI").append("svg")
        .attr("id","NZEIR")
        .attr("width", width)
        .attr("height", height)
        .append("g")
        .attr("transform", "translate(" + 110 + "," + 105 + ")");

        svg.append("g").attr("class", "slices");
        svg.append("g").attr("class", "labelName");
        svg.append("g").attr("class", "lines");

        var div = d3.select("body").append("div").attr("class", "toolTip");

        var links;
        var allRevenue=0;

        var city;
      var EmpID;
      var Division;
      var state;
      var SourceSite;
      var prname;
      var Zone;

        
        var pie = d3.layout.pie().value(function(d) { 
        return d.Revenue; });

        var otherEmpState="";
        var otherEmpStateRevenue=0;
        var links;

            var CWPQ=encodeURI("http://localhost/MACV/SalesRepInsight/data/CategorywisePerformanceQuantity.php");

            if (spzone === undefined && Sstate === undefined && scity === undefined  && Semp === undefined && SSite === undefined && Scate === undefined && prname === undefined && CatQtn === undefined) {

    links=(CWPQ+"?param=");

      }
else if((spzone) && Sstate === undefined && scity === undefined && Semp === undefined && SSite === undefined && Scate === undefined && prname === undefined && CatQtn === undefined)
    {
      links=(CWPQ+"?zoneparam="+spzone);

      d3.select("#NZEIR").remove();
    }

else if(spzone === undefined && Sstate  && scity === undefined && Semp === undefined && SSite === undefined && Scate === undefined && prname === undefined && CatQtn === undefined)
    {

    links=(CWPQ+"?Stateparam="+Sstate);
    console.log("city",links)
    
    d3.select("#NZEIR").remove();
  }

else if(spzone === undefined && Sstate === undefined && scity && Semp === undefined && SSite === undefined && Scate === undefined && prname === undefined && CatQtn === undefined)
  {

    links=(CWPQ+"?Cityparam="+scity);
      d3.select("#NZEIR").remove();

    //console.log("city",links)
}

else if(spzone === undefined && Sstate === undefined && scity === undefined  && Semp  && SSite === undefined && Scate === undefined && prname === undefined && CatQtn === undefined)
{

  links=(CWPQ+"?EmpIdparam="+Semp);
    d3.select("#NZEIR").remove();

  //console.log("ddddd",links);

}

else if(spzone === undefined && Sstate === undefined && scity === undefined  && Semp === undefined && SSite  && Scate === undefined && prname === undefined && CatQtn === undefined)
{
  links=(CWPQ+"?Siteparam="+SSite);

    d3.select("#NZEIR").remove();

}

else if (spzone === undefined && Sstate === undefined && scity === undefined  && Semp === undefined && SSite === undefined && Scate && prname === undefined && CatQtn === undefined)
{
links=(CWPQ+"?categoryparam="+Scate);

  d3.select("#NZEIR").remove();

//console.log("ddddd",links);
}
  
else if (spzone === undefined && Sstate === undefined && scity === undefined  && Semp === undefined && SSite === undefined && Scate=== undefined && prname  && CatQtn === undefined)
  {
    links=(CWPQ+"?ProNameparam="+prname);

      d3.select("#NZEIR").remove();
   }

   else
   {

    links=(CWPQ+"?CateQtnparam="+CatQtn);

    console.log(links);

      d3.select("#NZEIR").remove();

   }


        d3.json(links,function(error,data){
            data.forEach(function(d){
            if(d.Category=='All')
                {
                    allRevenue = d.Revenue;
                }
                });
            
        data.forEach(function(d){
            if(d.Category==pros && prosEmpId)
            {
                otherEmpStateRevenue =allRevenue - d.Revenue;
                data.push({
                    Category: 'Other EmpStates',
                    Revenue: otherEmpStateRevenue
                });
            }
        });


  var data1 = d3.nest()
    .rollup(function(v) { 
   return {
    total: d3.sum(v, function(d) { return d.Revenue; })};
  }).entries(data);


    remove('Category', 'All', data);

    var desig;
    var emp;
    var startDate;
    var endDate;

    var slice = svg.select(".slices").selectAll("path.slice")
            .data(pie(data), function(d){

     return d.data.Category });

        slice.enter()
            .insert("path")
            .style("fill", function(d) { return color(d.data.Category); })
            .attr("class", "slice");

        slice
            .transition().duration(1000)
            .attrTween("d", function(d) {

                this._current = this._current || d;
                var interpolate = d3.interpolate(this._current, d);
                this._current = interpolate(0);
                return function(t) {
                    return arc(interpolate(t));
                };
            })
        slice
            .on("mousemove", function(d){
                div.style("left", d3.event.pageX+10+"px");
                div.style("top", d3.event.pageY-25+"px");
                div.style("display", "inline-block");
                div.html("Category:"+" "+(d.data.Category)+"<br>"+"QTY:"+d.data.Revenue +"("+((d.data.Revenue)*100/data1.total).toFixed(2)+"%"+")" );
            });
        slice
            .on("mouseout", function(d){
                div.style("display", "none");
            })
        slice.on("click", function(d){
            //console.log("CIRCLE",d.data.EmpState);
            if(d.data.Category == "Other EmpStates")
            {
                return;
            }
            SalesPerformanceQtns(Zone,state,city,EmpID,SourceSite,Division,prname,d.data.Category);
            //render_NZmapchart(desig,d.data.EmpState,emp,startDate,endDate);
        });

        slice.exit()
            .remove();

    var text = svg.select(".labelName").selectAll("text")
            .data(pie(data), function(d){ return d.data.Category });


           text.enter().append("text")
                .attr("transform", function(d,i){
                var pos = outerArc.centroid(d);
                pos[0] = radius *.50* (midAngle(d) < Math.PI ? 1.1 : -1.1);
        
    
    var percent = (d.endAngle - d.startAngle)/(2*Math.PI)*100
         if(percent<7){
         //console.log(percent)
         pos[1] += i*15
         }
          return "translate("+ pos +")";
        })
        .text(function(d) { return d.data.Category; })
        .attr("fill", function(d,i) { return "White"; })
        //.attr("text-anchor", 'left')
        .attr("font-weight", 'bold')
        .attr("font-size", '10px')
        .attr("dx", function(d){
        var ac = midAngle(d) < Math.PI ? 0:-50
                return ac
        }).attr("dy", 5 )
       
        function midAngle(d){
            return d.startAngle + (d.endAngle - d.startAngle)/2;
        }

        text.exit()
            .remove();

        svg.selectAll("polyline")
              .data(pie(data), function(d) {
                return d.data.Revenue;
              })
              .enter()
              .append("polyline")
              .attr("points", function(d,i) {
                var pos = outerArc.centroid(d);
                    pos[0] = radius * .55 * (midAngle(d) < Math.PI ? 1 : -1);
                 var o=   outerArc.centroid(d)
         var percent = (d.endAngle -d.startAngle)/(2*Math.PI)*100
               if(percent<7){
               //console.log(percent)
               o[1] 
               pos[1] += i*15
               }
                return [arc.centroid(d),[o[0],pos[1]] , pos];
                  }).style("fill", "none")
                  //.attr('stroke','grey')
                  .attr("stroke", function(d,i) { return "red"; })
                  .style("stroke-width", "2px");

          function midAngle(d) {
                  return d.startAngle + (d.endAngle - d.startAngle)/2;
              } 
          }); 

    function dollarFormatter(n) {
      n = Math.round(n);
      var result = n;
      if (Math.abs(n) > 100000) {
        result = Math.round(n/100000) + 'L';
      }
      return  result;
    }

    function dollarFormatterL(n) {
      n = Math.round(n);
      var result = n;
      if (Math.abs(n) > 100000) {
        result = Math.round(n/100000);
      }
      return result;
    }
}
