$( document ).ready(function() {

  	Macv_Zone();
  
  });


function Macv_Zone(spzone,Sstate,scity,Semp,SSite,Scate,prname){

  //console.log(spzone,Sstate,scity,Semp);

  var zoneArray=[];

  var state;
  var city;
  var EmpID;

  //var All='';

//d3.json("http://localhost/MACV/SalesRepInsight/data/Zone.php",function(data){

   var links;

var pZone=encodeURI("http://localhost/MACV/SalesRepInsight/data/Zone.php");


if (spzone === undefined && Sstate === undefined && scity === undefined  && Semp === undefined && SSite === undefined && Scate === undefined && prname === undefined) {

    links=(pZone+"?param=");

      }
else if((spzone) && Sstate === undefined && scity === undefined && Semp === undefined && SSite === undefined && Scate === undefined && prname === undefined)
    {
      links=(pZone+"?zoneparam="+spzone);
    }

else if(spzone === undefined && Sstate  && scity === undefined && Semp === undefined && SSite === undefined && Scate === undefined && prname === undefined)
    {

    links=(pZone+"?Stateparam="+Sstate);

    //console.log("sssssssss",links);
      
  }

else if(spzone === undefined && Sstate === undefined && scity && Semp === undefined && SSite === undefined && Scate === undefined && prname === undefined)
  {

    links=(pZone+"?Cityparam="+scity);

    //console.log("city",links)
}

else if(spzone === undefined && Sstate === undefined && scity === undefined  && Semp  && SSite === undefined && Scate === undefined && prname === undefined)
{

  links=(pZone+"?EmpIdparam="+Semp);

  //console.log("ddddd",links);

}

else if(spzone === undefined && Sstate === undefined && scity === undefined  && Semp === undefined && SSite  && Scate === undefined && prname === undefined)
{
  links=(pZone+"?Siteparam="+SSite);

}

else if (spzone === undefined && Sstate === undefined && scity === undefined  && Semp === undefined && SSite === undefined && Scate && prname === undefined)
{
links=(pZone+"?categoryparam="+Scate);

//console.log("ddddd",links);
}
  
  else
  {
    links=(pZone+"?ProNameparam="+prname);

    
    
    }

  d3.json(links,function(error, data) {
  
  data.forEach(function(d) { 
     d.Zone = d.Zone;
    
    });


    //console.log(JSON.stringify(zoneArray));

data.sort(function(a, c) { return c.count - a.count; });

d3.select("#MacDZ").html("");

function wrap(text, width) {
        text.each(function() {
        var text = d3.select(this),
        words = text.text().split(/\s+/).reverse(),
        word,
        line = [],
        lineNumber = 0, //<-- 0!
        lineHeight = 1.2, // ems
        x = text.attr("x"), //<-- include the x!
        y = text.attr("y"),
        dy = text.attr("dy") ? text.attr("dy") : 0; //<-- null check
        tspan = text.text(null).append("tspan").attr("x", x).attr("y", y).attr("dy", dy + "em");
        while (word = words.pop()) {
            line.push(word);
            tspan.text(line.join(" "));
            /*if (tspan.node().getComputedTextLength() > width) {
                line.pop();
                tspan.text(line.join(" "));
                line = [word];
               // tspan = text.append("tspan").attr("x", x).attr("y", y).attr("dy", ++lineNumber * lineHeight + dy + "em").text(word);
            }*/
        }
    });
}

//var data = ["Option 1", "Option 2", "Option 3"];

var select = d3.select('#MacDZ')
    .append('select')
    .attr('class','MacdivZ')
    .on("change", function(d){
     Macv_State(this.options[this.selectedIndex].value,state,city,EmpID);
     Macv_City(this.options[this.selectedIndex].value,state,city,EmpID);
     Macv_EmpId(this.options[this.selectedIndex].value,state,city,EmpID);
     Macv_SourceSite(this.options[this.selectedIndex].value,state,city,EmpID);
     Macv_Category(this.options[this.selectedIndex].value,state,city,EmpID);
     Macv_Promoname(this.options[this.selectedIndex].value,state,city,EmpID);
  });

 
var selectUI = select
             .selectAll("option")
             .data(data)
             .enter()
             .append("option")
             .text(function(d){return d.Zone;}).style("font-weight","bold").style("font-family",'Open Sans')
             .call(wrap, 50);
    });

}
