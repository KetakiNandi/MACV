<?php

 $param = $_GET['param'];
 $statename = $_GET['Stateparam'];
 $Cityname = $_GET['Cityparam'];
 $zonename = $_GET['zoneparam'];
 $Sitename = $_GET['Siteparam'];
 $EmpIdname = $_GET['EmpIdparam'];
 $categoryname = $_GET['categoryparam'];
 $Promoname = $_GET['ProNameparam'];

 $Catename = $_GET['CatQtnparam'];


$mng                  = new MongoDB\Driver\Manager("mongodb://127.0.0.1/");


$statefilter['State'] = $statename;
$Cityfilter['City'] = $Cityname;
$zonefilter['Zone'] = $zonename;
$Sitefilter['SourceSite'] = $Sitename;

$Empfilter['SalesRepNameid'] = $EmpIdname;
$catefilter['Category'] = $categoryname;
$promoNamefilter['PromoName'] = $Promoname;

$CateNamefilter['Category'] = $Catename;

if($zonefilter['Zone'])
      {
        $query                = new MongoDB\Driver\Query($zonefilter);
        $rows                 = $mng->executeQuery("SaleRepInsight.ZoneWiseStateWiseCityWiseSourceSiteWiseSalesPerformanceQuantity", $query);
        $data                 = array();
        $findCounter          = 0;
        foreach ($rows as $row){
         $milliseconds = $row->date->toDateTime();
        for($i=0;$i<count($data);$i++){
          if($data[$i]["Month"]==$milliseconds->format('M-Y')){          
            $findCounter    = 1;
            $oldV           = $data[$i]["Count"];
            $data[$i]["Count"]    = $oldV+$row->Count;     
            break;
          }
        }
        if($findCounter==0){
          $data[$i]     =  array("Month"=>($milliseconds->format('M-Y')),"Count"=>($row->Count));
        } else {
          $findCounter  = 0;
        }
       }
        array_walk_recursive($data, function (&$b) { $b = (string)$b; });
        echo json_encode($data);

      }

else if($statefilter['State'])
      {
        $query                = new MongoDB\Driver\Query($statefilter);
        $rows                 = $mng->executeQuery("SaleRepInsight.ZoneWiseStateWiseCityWiseSourceSiteWiseSalesPerformanceQuantity", $query);
        $data                 = array();
        $findCounter          = 0;
        foreach ($rows as $row){
         $milliseconds = $row->date->toDateTime();
        for($i=0;$i<count($data);$i++){
          if($data[$i]["Month"]==$milliseconds->format('M-Y')){          
            $findCounter    = 1;
            $oldV           = $data[$i]["Count"];
            $data[$i]["Count"]    = $oldV+$row->Count;     
            break;
          }
        }
        if($findCounter==0){
          $data[$i]     =  array("Month"=>($milliseconds->format('M-Y')),"Count"=>($row->Count));
        } else {
          $findCounter  = 0;
        }
       }
        array_walk_recursive($data, function (&$b) { $b = (string)$b; });
        echo json_encode($data);

      }

else if($Cityfilter['City'])
      {
         $query                = new MongoDB\Driver\Query($Cityfilter);
        $rows                 = $mng->executeQuery("SaleRepInsight.ZoneWiseStateWiseCityWiseSourceSiteWiseSalesPerformanceQuantity", $query);
        $data                 = array();
        $findCounter          = 0;
        foreach ($rows as $row){
         $milliseconds = $row->date->toDateTime();
        for($i=0;$i<count($data);$i++){
          if($data[$i]["Month"]==$milliseconds->format('M-Y')){          
            $findCounter    = 1;
            $oldV           = $data[$i]["Count"];
            $data[$i]["Count"]    = $oldV+$row->Count;     
            break;
          }
        }
        if($findCounter==0){
          $data[$i]     =  array("Month"=>($milliseconds->format('M-Y')),"Count"=>($row->Count));
        } else {
          $findCounter  = 0;
        }
       }
        array_walk_recursive($data, function (&$b) { $b = (string)$b; });
        echo json_encode($data);

      }

else if($Sitefilter['SourceSite'])
      {
        $query                = new MongoDB\Driver\Query($Sitefilter);

        $rows                 = $mng->executeQuery("SaleRepInsight.ZoneWiseStateWiseCityWiseSourceSiteWiseSalesPerformanceQuantity", $query);
        $data                 = array();
        $findCounter          = 0;
        foreach ($rows as $row){
         $milliseconds = $row->date->toDateTime();
        for($i=0;$i<count($data);$i++){
          if($data[$i]["Month"]==$milliseconds->format('M-Y')){          
            $findCounter    = 1;
            $oldV           = $data[$i]["Count"];
            $data[$i]["Count"]    = $oldV+$row->Count;     
            break;
          }
        }
        if($findCounter==0){
          $data[$i]     =  array("Month"=>($milliseconds->format('M-Y')),"Count"=>($row->Count));
        } else {
          $findCounter  = 0;
        }
       }
        array_walk_recursive($data, function (&$b) { $b = (string)$b; });
        echo json_encode($data);

      }

else if($Empfilter['SalesRepNameid'])
      {
        $query                = new MongoDB\Driver\Query($Empfilter);

        $rows                 = $mng->executeQuery("SaleRepInsight.RepNameWiseCategoryWisePromoNameWiseSalesPerformanceQuantity", $query);
        $data                 = array();
        $findCounter          = 0;
        foreach ($rows as $row){
         $milliseconds = $row->date->toDateTime();
        for($i=0;$i<count($data);$i++){
          if($data[$i]["Month"]==$milliseconds->format('M-Y')){          
            $findCounter    = 1;
            $oldV           = $data[$i]["Count"];
            $data[$i]["Count"]    = $oldV+$row->Count;     
            break;
          }
        }
        if($findCounter==0){
          $data[$i]     =  array("Month"=>($milliseconds->format('M-Y')),"Count"=>($row->Count));
        } else {
          $findCounter  = 0;
        }
       }
        array_walk_recursive($data, function (&$b) { $b = (string)$b; });
        echo json_encode($data);
      }

else if($catefilter['Category'])
      {
        $query                = new MongoDB\Driver\Query($catefilter);

        $rows                 = $mng->executeQuery("SaleRepInsight.RepNameWiseCategoryWisePromoNameWiseSalesPerformanceQuantity", $query);
        $data                 = array();
        $findCounter          = 0;
        foreach ($rows as $row){
         $milliseconds = $row->date->toDateTime();
        for($i=0;$i<count($data);$i++){
          if($data[$i]["Month"]==$milliseconds->format('M-Y')){          
            $findCounter    = 1;
            $oldV           = $data[$i]["Count"];
            $data[$i]["Count"]    = $oldV+$row->Count;     
            break;
          }
        }
        if($findCounter==0){
          $data[$i]     =  array("Month"=>($milliseconds->format('M-Y')),"Count"=>($row->Count));
        } else {
          $findCounter  = 0;
        }
       }
        array_walk_recursive($data, function (&$b) { $b = (string)$b; });
        echo json_encode($data);
      }
  else if($promoNamefilter['PromoName'])
      {
        $query                = new MongoDB\Driver\Query($promoNamefilter);

        $rows                 = $mng->executeQuery("SaleRepInsight.RepNameWiseCategoryWisePromoNameWiseSalesPerformanceQuantity", $query);
        $data                 = array();
        $findCounter          = 0;
        foreach ($rows as $row){
         $milliseconds = $row->date->toDateTime();
        for($i=0;$i<count($data);$i++){
          if($data[$i]["Month"]==$milliseconds->format('M-Y')){          
            $findCounter    = 1;
            $oldV           = $data[$i]["Count"];
            $data[$i]["Count"]    = $oldV+$row->Count;     
            break;
          }
        }
        if($findCounter==0){
          $data[$i]     =  array("Month"=>($milliseconds->format('M-Y')),"Count"=>($row->Count));
        } else {
          $findCounter  = 0;
        }
       }
        array_walk_recursive($data, function (&$b) { $b = (string)$b; });
        echo json_encode($data);
    }

else if($promoNamefilter['PromoName'])
      {
        $query                = new MongoDB\Driver\Query($promoNamefilter);

        $rows                 = $mng->executeQuery("SaleRepInsight.RepNameWiseCategoryWisePromoNameWiseSalesPerformanceQuantity", $query);//2nd collection
        $data                 = array();
        $findCounter          = 0;
        foreach ($rows as $row){
         $milliseconds = $row->date->toDateTime();
        for($i=0;$i<count($data);$i++){
          if($data[$i]["Month"]==$milliseconds->format('M-Y')){          
            $findCounter    = 1;
            $oldV           = $data[$i]["Count"];
            $data[$i]["Count"]    = $oldV+$row->Count;     
            break;
          }
        }
        if($findCounter==0){
          $data[$i]     =  array("Month"=>($milliseconds->format('M-Y')),"Count"=>($row->Count));
        } else {
          $findCounter  = 0;
        }
       }
        array_walk_recursive($data, function (&$b) { $b = (string)$b; });
        echo json_encode($data);
    }

else if($catefilter['Category'])
      {
        $query                = new MongoDB\Driver\Query($catefilter);

        $rows                 = $mng->executeQuery("SaleRepInsight.RepNameWiseCategoryWisePromoNameWiseSalesPerformanceQuantity", $query);
        $data                 = array();
        $findCounter          = 0;
        foreach ($rows as $row){
         $milliseconds = $row->date->toDateTime();
        for($i=0;$i<count($data);$i++){
          if($data[$i]["Month"]==$milliseconds->format('M-Y')){          
            $findCounter    = 1;
            $oldV           = $data[$i]["Count"];
            $data[$i]["Count"]    = $oldV+$row->Count;     
            break;
          }
        }
        if($findCounter==0){
          $data[$i]     =  array("Month"=>($milliseconds->format('M-Y')),"Count"=>($row->Count));
        } else {
          $findCounter  = 0;
        }
       }
        array_walk_recursive($data, function (&$b) { $b = (string)$b; });
        echo json_encode($data);
    }

else if($CateNamefilter['Category'])
      {
        $query                = new MongoDB\Driver\Query($CateNamefilter);

        $rows                 = $mng->executeQuery("SaleRepInsight.SalesPerformanceValueWiseQuantityWiseCategoryWiseSubCategoryWiseCustomerDetailsFilled", $query);//3rd collections
        $data                 = array();
        $findCounter          = 0;
        foreach ($rows as $row){
         $milliseconds = $row->date->toDateTime();
        for($i=0;$i<count($data);$i++){
          if($data[$i]["Month"]==$milliseconds->format('M-Y')){          
            $findCounter    = 1;
            $oldV           = $data[$i]["Count"];
            $data[$i]["Count"]    = $oldV+$row->Quantity;     
            break;
          }
        }
        if($findCounter==0){
          $data[$i]     =  array("Month"=>($milliseconds->format('M-Y')),"Count"=>($row->Quantity));
        } else {
          $findCounter  = 0;
        }
       }
        array_walk_recursive($data, function (&$b) { $b = (string)$b; });
        echo json_encode($data);
    }






else
{
  $query                = new MongoDB\Driver\Query([]);
  $rows                 = $mng->executeQuery("SaleRepInsight.SalesPerformanceQtn", $query);
  $data                 = array();
  $findCounter          = 0;
  foreach ($rows as $row){
   $milliseconds = $row->date->toDateTime();
  for($i=0;$i<count($data);$i++){
    if($data[$i]["Month"]==$milliseconds->format('M-Y')){          
      $findCounter    = 1;
      $oldV           = $data[$i]["Count"];
      $data[$i]["Count"]    = $oldV+$row->Count;     
      break;
    }
  }
  if($findCounter==0){
    $data[$i]     =  array("Month"=>($milliseconds->format('M-Y')),"Count"=>($row->Count));
  } else {
    $findCounter  = 0;
  }
 }
  array_walk_recursive($data, function (&$b) { $b = (string)$b; });
  echo json_encode($data);

}
  
  
?>

