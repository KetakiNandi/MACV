
  <?php

 $param = $_GET['param'];
 $statename = $_GET['Stateparam'];
 $Cityname = $_GET['Cityparam'];
 $zonename = $_GET['zoneparam'];
 $Sitename = $_GET['Siteparam'];
 $EmpIdname = $_GET['EmpIdparam'];
 $categoryname = $_GET['categoryparam'];
 $Promoname = $_GET['ProNameparam'];


  $connection = new MongoDB\Driver\Manager("mongodb://127.0.0.1/");


$statefilter['State'] = $statename;
$Cityfilter['City'] = $Cityname;
$zonefilter['Zone'] = $zonename;
$Sitefilter['SourceSite'] = $Sitename;
$Empfilter['SalesRepNameid'] = $EmpIdname;
$catefilter['Category'] = $categoryname;
$promoNamefilter['PromoName'] = $Promoname;



if($zonefilter['Zone'])
    
    {
        $query = new MongoDB\Driver\Query($zonefilter); 
        $rows  = $connection->executeQuery("SaleRepInsight.ZoneWiseStateWiseCityWiseSourceSiteWiseSubCategoryWisePerformanceQuantity", $query);
        $result = array();
          foreach($rows as $row){
              for($i=0;$i<count($data);$i++){
              if($data[$i]["Category"]==trim($row->SubCategory)){    
                $findCounter    = 1;
                $oldV           = $data[$i]["Revenue"];
                $data[$i]["Revenue"]    = $oldV+$row->Quantity;      
                
                break;
              }


            }
            if($findCounter==0){
              
              $data[$i]     =  array("Category"=>trim($row->SubCategory),"Revenue"=>trim($row->Quantity));
            } 
            else {
              $findCounter  = 0;
            }
          }
          echo json_encode($data);

    }

else if($statefilter['State'])
    {
        $query = new MongoDB\Driver\Query($statefilter); 
        $rows  = $connection->executeQuery("SaleRepInsight.ZoneWiseStateWiseCityWiseSourceSiteWiseSubCategoryWisePerformanceQuantity", $query);
        $result = array();
          foreach($rows as $row){
              for($i=0;$i<count($data);$i++){
              if($data[$i]["Category"]==trim($row->SubCategory)){    
                $findCounter    = 1;
                $oldV           = $data[$i]["Revenue"];
                $data[$i]["Revenue"]    = $oldV+$row->Quantity;      
                
                break;
              }
            }
            if($findCounter==0){
            $data[$i]     =  array("Category"=>trim($row->SubCategory),"Revenue"=>trim($row->Quantity));
            } 
            else {
              $findCounter  = 0;
            }
          }
          echo json_encode($data);

    }

else if($Cityfilter['City'])
    {
        $query = new MongoDB\Driver\Query($Cityfilter); 
        $rows  = $connection->executeQuery("SaleRepInsight.ZoneWiseStateWiseCityWiseSourceSiteWiseSubCategoryWisePerformanceQuantity", $query);
        $result = array();
          foreach($rows as $row){
              for($i=0;$i<count($data);$i++){
              if($data[$i]["Category"]==trim($row->SubCategory)){    
                $findCounter    = 1;
                $oldV           = $data[$i]["Revenue"];
                $data[$i]["Revenue"]    = $oldV+$row->Quantity;      
                
                break;
              }
            }
            if($findCounter==0){
            $data[$i]     =  array("Category"=>trim($row->SubCategory),"Revenue"=>trim($row->Quantity));
            } 
            else {
              $findCounter  = 0;
            }
          }
          echo json_encode($data);

    }
else if($Sitefilter['SourceSite'])
    {
        $query = new MongoDB\Driver\Query($Sitefilter); 
        $rows  = $connection->executeQuery("SaleRepInsight.ZoneWiseStateWiseCityWiseSourceSiteWiseSubCategoryWisePerformanceQuantity", $query);
        $result = array();
          foreach($rows as $row){
              for($i=0;$i<count($data);$i++){
              if($data[$i]["Category"]==trim($row->SubCategory)){    
                $findCounter    = 1;
                $oldV           = $data[$i]["Revenue"];
                $data[$i]["Revenue"]    = $oldV+$row->Quantity;      
                
                break;
              }
            }
            if($findCounter==0){
            $data[$i]     =  array("Category"=>trim($row->SubCategory),"Revenue"=>trim($row->Quantity));
            } 
            else {
              $findCounter  = 0;
            }
          }
          echo json_encode($data);

    }

else if($catefilter['Category'])
    {
        $query = new MongoDB\Driver\Query($catefilter);

        $rows  = $connection->executeQuery("SaleRepInsight.RepNameWiseCategoryWisePromoNamewiseSubCategoryWisePerformanceQuantity", $query);//2nd collection
        $result = array();
          foreach($rows as $row){
              for($i=0;$i<count($data);$i++){
              if($data[$i]["Category"]==trim($row->SubCategory)){    
                $findCounter    = 1;
                $oldV           = $data[$i]["Revenue"];
                $data[$i]["Revenue"]    = $oldV+$row->Quantity;      
                
                break;
              }
            }
            if($findCounter==0){
            $data[$i]     =  array("Category"=>trim($row->SubCategory),"Revenue"=>trim($row->Quantity));
            } 
            else {
              $findCounter  = 0;
            }
          }
          echo json_encode($data);

    }


else if($Empfilter['SalesRepNameid'])
    {
        $query = new MongoDB\Driver\Query($Empfilter);

        $rows  = $connection->executeQuery("SaleRepInsight.RepNameWiseCategoryWisePromoNamewiseSubCategoryWisePerformanceQuantity", $query);//2nd collection
        $result = array();
          foreach($rows as $row){
              for($i=0;$i<count($data);$i++){
              if($data[$i]["Category"]==trim($row->SubCategory)){    
                $findCounter    = 1;
                $oldV           = $data[$i]["Revenue"];
                $data[$i]["Revenue"]    = $oldV+$row->Quantity;      
                
                break;
              }
            }
            if($findCounter==0){
            $data[$i]     =  array("Category"=>trim($row->SubCategory),"Revenue"=>trim($row->Quantity));
            } 
            else {
              $findCounter  = 0;
            }
          }
          echo json_encode($data);

    }

  else if($promoNamefilter['PromoName'])
    {
        $query = new MongoDB\Driver\Query($promoNamefilter);

        $rows  = $connection->executeQuery("SaleRepInsight.RepNameWiseCategoryWisePromoNamewiseSubCategoryWisePerformanceQuantity", $query);//2nd collection
        $result = array();
          foreach($rows as $row){
              for($i=0;$i<count($data);$i++){
              if($data[$i]["Category"]==trim($row->SubCategory)){    
                $findCounter    = 1;
                $oldV           = $data[$i]["Revenue"];
                $data[$i]["Revenue"]    = $oldV+$row->Quantity;      
                
                break;
              }
            }
            if($findCounter==0){
            $data[$i]     =  array("Category"=>trim($row->SubCategory),"Revenue"=>trim($row->Quantity));
            } 
            else {
              $findCounter  = 0;
            }
          }
          echo json_encode($data);

    }

else
{

  $query = new MongoDB\Driver\Query([]); 

          $rows  = $connection->executeQuery("SaleRepInsight.SubCategorywisePerformanceQuantity", $query);
          $result = array();
          foreach($rows as $row){
              for($i=0;$i<count($data);$i++){
              if($data[$i]["Category"]==trim($row->SubCategory)){          
                
                break;
              }


            }
            if($findCounter==0){
              
              $data[$i]     =  array("Category"=>trim($row->SubCategory),"Revenue"=>trim($row->Quantity));
            } 
            else {
              $findCounter  = 0;
            }
          }
          echo json_encode($data);

}

?>