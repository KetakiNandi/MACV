  <?php

  $param = $_GET['param'];
 $statename = $_GET['Stateparam'];
 $Cityname = $_GET['Cityparam'];
 $zonename = $_GET['zoneparam'];
 $Sitename = $_GET['Siteparam'];
 $EmpIdname = $_GET['EmpIdparam'];
 $categoryname = $_GET['categoryparam'];
 $Promoname = $_GET['ProNameparam'];


  $connection = new MongoDB\Driver\Manager("mongodb://127.0.0.1/");

$statefilter['State'] = $statename;
$Cityfilter['City'] = $Cityname;
$zonefilter['Zone'] = $zonename;
$Sitefilter['SourceSite'] = $Sitename;
$Empfilter['SalespersonId'] = $EmpIdname;
$catefilter['Category'] = $categoryname;
$promoNamefilter['PromoName'] = $Promoname;



if($zonefilter['Zone'])
{

  $query = new MongoDB\Driver\Query($zonefilter); 

          $rows  = $connection->executeQuery("SaleRepInsight.ZoneWiseStateWiseCityWiseSourceSiteWiseSalespersonWiseContributionQuantity", $query);
          $result = array();
          foreach($rows as $row){
              for($i=0;$i<count($data);$i++){
              if($data[$i]["SalespersonId"]==trim($row->SalespersonId)){  
               $findCounter    = 1;
                $oldV           = $data[$i]["percentage"];
                $data[$i]["percentage"]    = $oldV+$row->Quantity;                  
               break;
           }
          }

            if($findCounter==0){
              
             $data[$i]     =  array("Group"=>trim($row->Salesperson),"percentage"=>trim($row->Quantity),"PoSName"=>trim($row->City),"SourceSite"=>trim($row->SourceSite));
            } 
            else {
              $findCounter  = 0;
            }
          }
          echo json_encode($data);

}

else if($statefilter['State'])
{

  $query = new MongoDB\Driver\Query($statefilter); 

          $rows  = $connection->executeQuery("SaleRepInsight.ZoneWiseStateWiseCityWiseSourceSiteWiseSalespersonWiseContributionQuantity", $query);
          $result = array();
          foreach($rows as $row){
              for($i=0;$i<count($data);$i++){
              if($data[$i]["SalespersonId"]==trim($row->SalespersonId)){  
               $findCounter    = 1;
                $oldV           = $data[$i]["percentage"];
                $data[$i]["percentage"]    = $oldV+$row->Quantity;                  
               break;
           }
          }

            if($findCounter==0){
              
             $data[$i]     =  array("Group"=>trim($row->Salesperson),"percentage"=>trim($row->Quantity),"PoSName"=>trim($row->City),"SourceSite"=>trim($row->SourceSite));
            } 
            else {
              $findCounter  = 0;
            }
          }
          echo json_encode($data);

}

else if($Cityfilter['City'])
{

  $query = new MongoDB\Driver\Query($Cityfilter); 

          $rows  = $connection->executeQuery("SaleRepInsight.ZoneWiseStateWiseCityWiseSourceSiteWiseSalespersonWiseContributionQuantity", $query);
          $result = array();
          foreach($rows as $row){
              for($i=0;$i<count($data);$i++){
              if($data[$i]["SalespersonId"]==trim($row->SalespersonId)){  
               $findCounter    = 1;
                $oldV           = $data[$i]["percentage"];
                $data[$i]["percentage"]    = $oldV+$row->Quantity;                  
               break;
           }
          }

            if($findCounter==0){
              
             $data[$i]     =  array("Group"=>trim($row->Salesperson),"percentage"=>trim($row->Quantity),"PoSName"=>trim($row->City),"SourceSite"=>trim($row->SourceSite));
            } 
            else {
              $findCounter  = 0;
            }
          }
          echo json_encode($data);

}
else if($Sitefilter['SourceSite'])
{

        $query = new MongoDB\Driver\Query($Sitefilter); 

          $rows  = $connection->executeQuery("SaleRepInsight.ZoneWiseStateWiseCityWiseSourceSiteWiseSalespersonWiseContributionQuantity", $query);
          $result = array();
          foreach($rows as $row){
              for($i=0;$i<count($data);$i++){
              if($data[$i]["SalespersonId"]==trim($row->SalespersonId)){  
               $findCounter    = 1;
                $oldV           = $data[$i]["percentage"];
                $data[$i]["percentage"]    = $oldV+$row->Quantity;                  
               break;
           }
          }

            if($findCounter==0){
              
             $data[$i]     =  array("Group"=>trim($row->Salesperson),"percentage"=>trim($row->Quantity),"PoSName"=>trim($row->City),"SourceSite"=>trim($row->SourceSite));
            } 
            else {
              $findCounter  = 0;
            }
          }
          echo json_encode($data);

}


else if($Empfilter['SalespersonId'])
{

  $query = new MongoDB\Driver\Query($Empfilter); 

          $rows  = $connection->executeQuery("SaleRepInsight.RepNameWiseCategoryWisePromoNameWiseSalespersonWiseContributionQuantity", $query);//2nd collection

          $result = array();
          foreach($rows as $row){
              for($i=0;$i<count($data);$i++){
              if($data[$i]["SalespersonId"]==trim($row->SalespersonId)){  
               $findCounter    = 1;
                $oldV           = $data[$i]["percentage"];

                $data[$i]["percentage"]    = $oldV+$row->Quantity;                  
               break;
           }
          }

            if($findCounter==0){
              
             $data[$i]     =  array("Group"=>trim($row->Salesperson),"percentage"=>trim($row->Quantity),"PoSName"=>trim($row->City),"SourceSite"=>trim($row->SourceSite));
            } 
            else {
              $findCounter  = 0;
            }
          }
          echo json_encode($data);

}

else if($catefilter['Category'])
{

  $query = new MongoDB\Driver\Query($catefilter); 

          $rows  = $connection->executeQuery("SaleRepInsight.RepNameWiseCategoryWisePromoNameWiseSalespersonWiseContributionQuantity", $query);//2nd collection

          $result = array();
          foreach($rows as $row){
              for($i=0;$i<count($data);$i++){
              if($data[$i]["SalespersonId"]==trim($row->SalespersonId)){  
               $findCounter    = 1;
                $oldV           = $data[$i]["percentage"];

                $data[$i]["percentage"]    = $oldV+$row->Quantity;                  
               break;
           }
          }

            if($findCounter==0){
              
             $data[$i]     =  array("Group"=>trim($row->Salesperson),"percentage"=>trim($row->Quantity),"PoSName"=>trim($row->City),"SourceSite"=>trim($row->SourceSite));
            } 
            else {
              $findCounter  = 0;
            }
          }
          echo json_encode($data);

}
else if($promoNamefilter['PromoName'])
{

  $query = new MongoDB\Driver\Query($promoNamefilter); 

          $rows  = $connection->executeQuery("SaleRepInsight.RepNameWiseCategoryWisePromoNameWiseSalespersonWiseContributionQuantity", $query);//2nd collection

          $result = array();
          foreach($rows as $row){
              for($i=0;$i<count($data);$i++){
              if($data[$i]["SalespersonId"]==trim($row->SalespersonId)){  
               $findCounter    = 1;
                $oldV           = $data[$i]["percentage"];

                $data[$i]["percentage"]    = $oldV+$row->Quantity;                  
               break;
           }
          }

            if($findCounter==0){
              
             $data[$i]     =  array("Group"=>trim($row->Salesperson),"percentage"=>trim($row->Quantity),"PoSName"=>trim($row->City),"SourceSite"=>trim($row->SourceSite));
            } 
            else {
              $findCounter  = 0;
            }
          }
          echo json_encode($data);

}

else
{

  $query = new MongoDB\Driver\Query([]); 

          $rows  = $connection->executeQuery("SaleRepInsight.SalesPersonWiseContributionQuantity", $query);
          $result = array();
          foreach($rows as $row){
              for($i=0;$i<count($data);$i++){
              if($data[$i]["SalespersonId"]==trim($row->SalespersonId)){                  
               break;
           }
          }

            if($findCounter==0){
              
              $data[$i]     =  array("Group"=>trim($row->Salesperson),"percentage"=>trim($row->Quantity),"PoSName"=>trim($row->City),"SourceSite"=>trim($row->SourceSite));
            } 
            else {
              $findCounter  = 0;
            }
          }
          echo json_encode($data);


}

?>