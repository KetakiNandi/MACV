  <?php

 $param = $_GET['param'];
 $statename = $_GET['Stateparam'];
 $Cityname = $_GET['Cityparam'];
 $zonename = $_GET['zoneparam'];
 $Sitename = $_GET['Siteparam'];



$connection = new MongoDB\Driver\Manager("mongodb://127.0.0.1/");


$statefilter['State'] = $statename;
$Cityfilter['City'] = $Cityname;
$zonefilter['Zone'] = $zonename;
$Sitefilter['SourceSite'] = $Sitename;


if($zonefilter['Zone'])
{

  $query = new MongoDB\Driver\Query($zonefilter); 

          $rows  = $connection->executeQuery("SaleRepInsight.ZoneWiseStateWiseCityWiseSourceSiteWiseTop10sellingItemsQuantity", $query);
          $result = array();
          foreach($rows as $row){
              for($i=0;$i<count($data);$i++){
              if($data[$i]["Group"]==trim($row->Item_Code)){  

                $findCounter    = 1;
                $oldV           = $data[$i]["percentage"];
                $data[$i]["percentage"]    = $oldV+$row->Quantity;
              
              break;
              }
          }

        if($findCounter==0){
              
          $data[$i]     =  array("Group"=>trim($row->Item_Code),"PoSName"=>trim($row->SubCategory),"percentage"=>trim($row->Quantity));

            } 
            else {
              $findCounter  = 0;
            }
          }
          echo json_encode($data);

}

else if($statefilter['State'])
{
   $query = new MongoDB\Driver\Query($statefilter); 

          $rows  = $connection->executeQuery("SaleRepInsight.ZoneWiseStateWiseCityWiseSourceSiteWiseTop10sellingItemsQuantity", $query);
          $result = array();
          foreach($rows as $row){
              for($i=0;$i<count($data);$i++){
              if($data[$i]["Group"]==trim($row->Item_Code)){  

                $findCounter    = 1;
                $oldV           = $data[$i]["percentage"];
                $data[$i]["percentage"]    = $oldV+$row->Quantity;
                  
                  break;
              }
          }
            if($findCounter==0){
              
              $data[$i]     =  array("Group"=>trim($row->Item_Code),"PoSName"=>trim($row->SubCategory),"percentage"=>trim($row->Quantity));
            } 
            else {
              $findCounter  = 0;
            }
          }
          echo json_encode($data);
}

else if($Cityfilter['City'])
{
   $query = new MongoDB\Driver\Query($Cityfilter); 

          $rows  = $connection->executeQuery("SaleRepInsight.ZoneWiseStateWiseCityWiseSourceSiteWiseTop10sellingItemsQuantity", $query);
          $result = array();
          foreach($rows as $row){
              for($i=0;$i<count($data);$i++){
              if($data[$i]["Group"]==trim($row->Item_Code)){  

                $findCounter    = 1;
                $oldV           = $data[$i]["percentage"];
                $data[$i]["percentage"]    = $oldV+$row->Quantity;
                  
                  break;
              }
          }
            if($findCounter==0){
              
              $data[$i]     =  array("Group"=>trim($row->Item_Code),"PoSName"=>trim($row->SubCategory),"percentage"=>trim($row->Quantity));
            } 
            else {
              $findCounter  = 0;
            }
          }
          echo json_encode($data);
}

else if($Sitefilter['SourceSite'])
{
   $query = new MongoDB\Driver\Query($Sitefilter); 

          $rows  = $connection->executeQuery("SaleRepInsight.ZoneWiseStateWiseCityWiseSourceSiteWiseTop10sellingItemsQuantity", $query);
          $result = array();
          foreach($rows as $row){
              for($i=0;$i<count($data);$i++){
              if($data[$i]["Group"]==trim($row->Item_Code)){  

                $findCounter    = 1;
                $oldV           = $data[$i]["percentage"];
                $data[$i]["percentage"]    = $oldV+$row->Quantity;
                  
                  break;
              }
          }
            if($findCounter==0){
              
              $data[$i]     =  array("Group"=>trim($row->Item_Code),"PoSName"=>trim($row->SubCategory),"percentage"=>trim($row->Quantity));
            } 
            else {
              $findCounter  = 0;
            }
          }
          echo json_encode($data);
}

else
{

  $query = new MongoDB\Driver\Query([]); 

          $rows  = $connection->executeQuery("SaleRepInsight.Top10SellingItem", $query);
          $result = array();
          foreach($rows as $row){
              for($i=0;$i<count($data);$i++){
              if($data[$i]["Group"]==trim($row->Item_Code)){          
                
                break;
              }


            }
            if($findCounter==0){
              
              $data[$i]     =  array("Group"=>trim($row->Item_Code),"PoSName"=>trim($row->SubCategory),"percentage"=>trim($row->Quantity));
            } 
            else {
              $findCounter  = 0;
            }
          }
          echo json_encode($data);
}



?>