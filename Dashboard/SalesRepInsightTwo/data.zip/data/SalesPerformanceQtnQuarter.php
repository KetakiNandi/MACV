 <?php

  $connection = new MongoDB\Driver\Manager("mongodb://127.0.0.1/");

  $query = new MongoDB\Driver\Query([]); 

          $rows  = $connection->executeQuery("SaleRepInsight.SalesPerformanceQtnQuarter", $query);
          $result = array();
          foreach($rows as $row){
              for($i=0;$i<count($data);$i++){
              if($data[$i]["Quarter"]==trim($row->Quarter)){  

               $findCounter    = 1;
              $oldV           = $data[$i]["Quantity"];
              $data[$i]["Quantity"]    = $oldV+$row->Quantity;            
                
                break;
              }


            }
            if($findCounter==0){
              
              $data[$i]     =  array("Quarter"=>trim($row->Quarter),"Quantity"=>trim($row->Quantity));
            } 
            else {
              $findCounter  = 0;
            }
          }
          echo json_encode($data);


?>