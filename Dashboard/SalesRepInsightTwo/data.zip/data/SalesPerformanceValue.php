<?php

 $param = $_GET['param'];
 $statename = $_GET['Stateparam'];
 $Cityname = $_GET['Cityparam'];
 $zonename = $_GET['zoneparam'];
 $Sitename = $_GET['Siteparam'];
 $categoryname = $_GET['categoryparam'];
 $Promoname = $_GET['ProNameparam'];
 $EmpIdname = $_GET['EmpIdparam'];


$mng                  = new MongoDB\Driver\Manager("mongodb://127.0.0.1/");


$statefilter['State'] = $statename;
$Cityfilter['City'] = $Cityname;
$zonefilter['Zone'] = $zonename;
$Sitefilter['SourceSite'] = $Sitename;
$Empfilter['SalesRepNameid'] = $EmpIdname;
$catefilter['Category'] = $categoryname;
$promoNamefilter['PromoName'] = $Promoname;


//$mongoStartDate =  new \MongoDB\BSON\UTCDateTime($miliStartDate*1000);
//$mongoEndDate =  new \MongoDB\BSON\UTCDateTime($miliEndDate*1000);

//$datefilter=array('SnappyDate'=> array('$gte' => $mongoStartDate, '$lte' => $mongoEndDate));

if($zonefilter['Zone'])
{
  $query                = new MongoDB\Driver\Query($zonefilter);
  $rows                 = $mng->executeQuery("SaleRepInsight.ZoneWiseStateWiseCityWiseSourceSiteWiseSalesPerformanceValue", $query);
  $data                 = array();
  $findCounter          = 0;
  foreach ($rows as $row){
   $milliseconds = $row->date->toDateTime();
  for($i=0;$i<count($data);$i++){
    if($data[$i]["Month"]==$milliseconds->format('M-Y')){          
      $findCounter    = 1;
      $oldV           = $data[$i]["Amount"];
      $data[$i]["Amount"]    = $oldV+$row->Amount;     
      break;
    }
  }
  if($findCounter==0){
    $data[$i]     =  array("Month"=>($milliseconds->format('M-Y')),"Amount"=>($row->Amount));
  } else {
    $findCounter  = 0;
  }
 }
  array_walk_recursive($data, function (&$b) { $b = (string)$b; });
  echo json_encode($data);

}

else if($statefilter['State'])
{
  $query                = new MongoDB\Driver\Query($statefilter);
  $rows                 = $mng->executeQuery("SaleRepInsight.ZoneWiseStateWiseCityWiseSourceSiteWiseSalesPerformanceValue", $query);
  $data                 = array();
  $findCounter          = 0;
  foreach ($rows as $row){
   $milliseconds = $row->date->toDateTime();
  for($i=0;$i<count($data);$i++){
    if($data[$i]["Month"]==$milliseconds->format('M-Y')){          
      $findCounter    = 1;
      $oldV           = $data[$i]["Amount"];
      $data[$i]["Amount"]    = $oldV+$row->Amount;     
      break;
    }
  }
  if($findCounter==0){
    $data[$i]     =  array("Month"=>($milliseconds->format('M-Y')),"Amount"=>($row->Amount));
  } else {
    $findCounter  = 0;
  }
 }
  array_walk_recursive($data, function (&$b) { $b = (string)$b; });
  echo json_encode($data);

}

 else if($Cityfilter['City'])
{
  $query                = new MongoDB\Driver\Query($Cityfilter);
  $rows                 = $mng->executeQuery("SaleRepInsight.ZoneWiseStateWiseCityWiseSourceSiteWiseSalesPerformanceValue", $query);
  $data                 = array();
  $findCounter          = 0;
  foreach ($rows as $row){
   $milliseconds = $row->date->toDateTime();
  for($i=0;$i<count($data);$i++){
    if($data[$i]["Month"]==$milliseconds->format('M-Y')){          
      $findCounter    = 1;
      $oldV           = $data[$i]["Amount"];
      $data[$i]["Amount"]    = $oldV+$row->Amount;     
      break;
    }
  }
  if($findCounter==0){
    $data[$i]     =  array("Month"=>($milliseconds->format('M-Y')),"Amount"=>($row->Amount));
  } else {
    $findCounter  = 0;
  }
 }
  array_walk_recursive($data, function (&$b) { $b = (string)$b; });
  echo json_encode($data);

}

else if($Sitefilter['SourceSite'])
{
  $query                = new MongoDB\Driver\Query($Sitefilter);
  $rows                 = $mng->executeQuery("SaleRepInsight.ZoneWiseStateWiseCityWiseSourceSiteWiseSalesPerformanceValue", $query);
  $data                 = array();
  $findCounter          = 0;
  foreach ($rows as $row){
   $milliseconds = $row->date->toDateTime();
  for($i=0;$i<count($data);$i++){
    if($data[$i]["Month"]==$milliseconds->format('M-Y')){          
      $findCounter    = 1;
      $oldV           = $data[$i]["Amount"];
      $data[$i]["Amount"]    = $oldV+$row->Amount;     
      break;
    }
  }
  if($findCounter==0){
    $data[$i]     =  array("Month"=>($milliseconds->format('M-Y')),"Amount"=>($row->Amount));
  } else {
    $findCounter  = 0;
  }
 }
  array_walk_recursive($data, function (&$b) { $b = (string)$b; });
  echo json_encode($data);

}

else if($catefilter['Category'])
{
  $query                = new MongoDB\Driver\Query($catefilter);
  $rows                 = $mng->executeQuery("SaleRepInsight.RepNameWiseCategoryWisePromoNameWiseSalesPerformanceValue", $query);//2nd Collection saleRep,cat,pn
  $data                 = array();
  $findCounter          = 0;
  foreach ($rows as $row){
   $milliseconds = $row->date->toDateTime();
  for($i=0;$i<count($data);$i++){
    if($data[$i]["Month"]==$milliseconds->format('M-Y')){          
      $findCounter    = 1;
      $oldV           = $data[$i]["Amount"];
      $data[$i]["Amount"]    = $oldV+$row->Amount;     
      break;
    }
  }
  if($findCounter==0){
    $data[$i]     =  array("Month"=>($milliseconds->format('M-Y')),"Amount"=>($row->Amount));
  } else {
    $findCounter  = 0;
  }
 }
  array_walk_recursive($data, function (&$b) { $b = (string)$b; });
  echo json_encode($data);

}

else if($promoNamefilter['PromoName'] )
{
  $query                = new MongoDB\Driver\Query($promoNamefilter);

  $rows                 = $mng->executeQuery("SaleRepInsight.RepNameWiseCategoryWisePromoNameWiseSalesPerformanceValue", $query);//2nd Collection saleRep,cat,pn
  $data                 = array();
  $findCounter          = 0;
  foreach ($rows as $row){
   $milliseconds = $row->date->toDateTime();
  for($i=0;$i<count($data);$i++){
    if($data[$i]["Month"]==$milliseconds->format('M-Y')){          
      $findCounter    = 1;
      $oldV           = $data[$i]["Amount"];
      $data[$i]["Amount"]    = $oldV+$row->Amount;     
      break;
    }
  }
  if($findCounter==0){
    $data[$i]     =  array("Month"=>($milliseconds->format('M-Y')),"Amount"=>($row->Amount));
  } else {
    $findCounter  = 0;
  }
 }
  array_walk_recursive($data, function (&$b) { $b = (string)$b; });
  echo json_encode($data);

}

else if($Empfilter['SalesRepNameid'])
{
  $query                = new MongoDB\Driver\Query($Empfilter);
  
  $rows                 = $mng->executeQuery("SaleRepInsight.RepNameWiseCategoryWisePromoNameWiseSalesPerformanceValue", $query);//2nd Collection saleRep,cat,pn
  $data                 = array();
  $findCounter          = 0;
  foreach ($rows as $row){
   $milliseconds = $row->date->toDateTime();
  for($i=0;$i<count($data);$i++){
    if($data[$i]["Month"]==$milliseconds->format('M-Y')){          
      $findCounter    = 1;
      $oldV           = $data[$i]["Amount"];
      $data[$i]["Amount"]    = $oldV+$row->Amount;     
      break;
    }
  }
  if($findCounter==0){
    $data[$i]     =  array("Month"=>($milliseconds->format('M-Y')),"Amount"=>($row->Amount));
  } else {
    $findCounter  = 0;
  }
 }
  array_walk_recursive($data, function (&$b) { $b = (string)$b; });
  echo json_encode($data);

}

else

    {
          $query                = new MongoDB\Driver\Query([]);
          $rows                 = $mng->executeQuery("SaleRepInsight.SalesperformanceValue", $query);
          $data                 = array();
          $findCounter          = 0;
          foreach ($rows as $row){
           $milliseconds = $row->date->toDateTime();
          for($i=0;$i<count($data);$i++){
            if($data[$i]["Month"]==$milliseconds->format('M-Y')){          
              $findCounter    = 1;
              $oldV           = $data[$i]["Amount"];
              $data[$i]["Amount"]    = $oldV+$row->Amount;     
              break;
            }
          }
          if($findCounter==0){
            $data[$i]     =  array("Month"=>($milliseconds->format('M-Y')),"Amount"=>($row->Amount));
          } else {
            $findCounter  = 0;
          }
         }
          array_walk_recursive($data, function (&$b) { $b = (string)$b; });
          echo json_encode($data);

  }

?>

