 <?php

  $param = $_GET['param'];
  $startDate = $_GET['startDate'];//01-Jan-17
  $endDate = $_GET['endDate'];//31-Jan-17
  $miliStartDate = strtotime($startDate);
  $miliEndDate = strtotime($endDate);
  $connection = new MongoDB\Driver\Manager("mongodb://127.0.0.1/");
  $mongoStartDate =  new \MongoDB\BSON\UTCDateTime($miliStartDate*1000);
  $mongoEndDate =  new \MongoDB\BSON\UTCDateTime($miliEndDate*1000);
  $datefilter=array('date'=> array('$gte' => $mongoStartDate, '$lte' => $mongoEndDate));

  if($startDate && $endDate){
  $query                = new MongoDB\Driver\Query($datefilter);
  $rows                 = $connection->executeQuery("SaleRepInsight.SalesperformanceValue", $query);
   $result = array();
          foreach($rows as $row){
            $milliseconds = $row->date->toDateTime();
              for($i=0;$i<count($data);$i++){
              if($data[$i]["Quarter"]==trim($row->date)){  

               $findCounter    = 1;
              $oldV           = $data[$i]["Amount"];
              $data[$i]["Amount"]    = $oldV+$row->Amount;            
                
                break;
              }

            }
            if($findCounter==0){
              
              $data[$i]     =  array("Quarter"=>trim($row->date),"Amount"=>trim($row->Amount));
            } 
            else {
              $findCounter  = 0;
            }
          }
  array_walk_recursive($data, function (&$b) { $b = (string)$b; });
  echo json_encode($data);
  }
else{
  $query = new MongoDB\Driver\Query([]); 

          $rows  = $connection->executeQuery("SaleRepInsight.SalesperformanceValueQuarter", $query);
          $result = array();
          foreach($rows as $row){
              for($i=0;$i<count($data);$i++){
              if($data[$i]["Quarter"]==trim($row->Quarter)){  

               $findCounter    = 1;
              $oldV           = $data[$i]["Amount"];
              $data[$i]["Amount"]    = $oldV+$row->Amount;            
                
                break;
              }

            }
            if($findCounter==0){
              
              $data[$i]     =  array("Quarter"=>trim($row->Quarter),"Amount"=>trim($row->Amount));
            } 
            else {
              $findCounter  = 0;
            }
          }
          echo json_encode($data);

}
?>